﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TestTareas.Models;

namespace TestTareas.Controllers
{
    public class AdministradorController : Controller
    {
        private readonly ILogger<AdministradorController> _logger;
        private readonly BDS_Gestion_tareasContext _db;

        public AdministradorController(ILogger<AdministradorController> logger, BDS_Gestion_tareasContext bDS_Gestion_tareasContext)
        {
            _logger = logger;
            _db = bDS_Gestion_tareasContext;
        }

        public IActionResult Index()
        {
            return View(_db.TblUsuarios.ToList());
        }

        public IActionResult Empresas()
        {
            return View(_db.TblEmpresas.ToList());
        }

        public IActionResult Roles()
        {
            return View(_db.TblRols.ToList());
        }

        public IActionResult Tareas()
        {
            return View(_db.TblTareas.ToList());
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TestTareas.Models;

namespace TestTareas.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly BDS_Gestion_tareasContext _db;

        public HomeController(ILogger<HomeController> logger, BDS_Gestion_tareasContext bDS_Gestion_tareasContext)
        {
            _logger = logger;
            _db = bDS_Gestion_tareasContext;
        }

        public IActionResult Index()
        {
            return View(_db.TblUsuarios.ToList());
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

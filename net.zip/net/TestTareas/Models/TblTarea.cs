﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TestTareas.Models
{
    public partial class TblTarea
    {
        public string TraNombre { get; set; }
        public string TraDescripcion { get; set; }
        public DateTime? TraFechaInicio { get; set; }
        public DateTime? TraFechaFinal { get; set; }
        public int PkTraIdTarea { get; set; }
        public string TraEstado { get; set; }
    }
}

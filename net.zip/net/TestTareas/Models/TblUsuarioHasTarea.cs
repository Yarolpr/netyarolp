﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TestTareas.Models
{
    public partial class TblUsuarioHasTarea
    {
        public int? FkUsuIdUsuario { get; set; }
        public int? FkTraIdTarea { get; set; }

        public virtual TblTarea FkTraIdTareaNavigation { get; set; }
        public virtual TblUsuario FkUsuIdUsuarioNavigation { get; set; }
    }
}
